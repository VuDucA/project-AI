
thanh long detection - v1 2022-06-23 2:49am
==============================

This dataset was exported via roboflow.ai on June 22, 2022 at 7:50 PM GMT

It includes 264 images.
Trang are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)

No image augmentation techniques were applied.


